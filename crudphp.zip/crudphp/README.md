# WebCRUD
silahkan di Lihat,Ambil,Modifikasi (LAM)

TAMPILAN WEBSITE
![gambar](https://user-images.githubusercontent.com/100106630/162618264-44bcdab9-7a52-4587-84d4-e4f3c4f0930a.png)
![gambar](https://user-images.githubusercontent.com/100106630/162618268-0a9a58a8-3ebf-40ed-ab61-367999d0e839.png)
![gambar](https://user-images.githubusercontent.com/100106630/162618296-f795d63d-b945-444d-87ee-e419efb3a075.png)
![gambar](https://user-images.githubusercontent.com/100106630/162618348-9e8a5b09-c24c-4a51-83e5-567c1e829c94.png)
